#include "model3D.hlsli"

struct Material {
    float32_t4 color;
    int32_t enableLighting;
    float32_t3 padding;
    float32_t4x4 uvTransform;
};

struct DirectionalLight {
    float32_t4 color;
    float32_t3 direction;
    float32_t intensity;
    int32_t lightMode;
};

ConstantBuffer<Material> gMaterial : register(b0);

Texture2D<float32_t4> gTexture : register(t0);
SamplerState gSampler : register(s0);

ConstantBuffer<DirectionalLight> gDirectionalLight : register(b1);

struct PixelShaderOutput {
    float32_t4 color : SV_TARGET0;
};

PixelShaderOutput main(VertexShaderOutput input) {
    PixelShaderOutput output;

    // テクスチャから色をサンプリング
    float32_t4 textureColor = gTexture.Sample(gSampler, input.texcoord);
    
    // ベース色を計算
    float32_t4 baseColor = gMaterial.color * textureColor;
    
    if (gMaterial.enableLighting != 0) {
        float32_t3 N = normalize(input.normal);
        float32_t3 L = normalize(-gDirectionalLight.direction);
        float32_t NdotL = dot(N, L);
        
        float32_t diffuseFactor = 1.0f;
    
        if (gDirectionalLight.lightMode == 1) {
            diffuseFactor = saturate(NdotL);
        } else if (gDirectionalLight.lightMode == 2) {
            diffuseFactor = pow(NdotL * 0.5f + 0.5f, 2.0f);
        }
    
        output.color.rgb = baseColor.rgb * gDirectionalLight.color.rgb * diffuseFactor * gDirectionalLight.intensity;
        output.color.a = baseColor.a;
    
        if (output.color.a == 0.0f) {
            discard;
        }
    } else {
        output.color = baseColor;
    }
    
    return output;
}