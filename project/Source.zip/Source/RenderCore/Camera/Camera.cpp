#include "Camera.h"

#include "Math/VectorFunctions.h"
#include "Math/MatrixFunctions.h"

#include <cassert>

namespace Tuna {
    void Camera::SetScreenSize(float width, float height) {
        assert(width > 0.0f);
        assert(height > 0.0f);

        width_ = width;
        height_ = height;
    }

    void Camera::Update(const Transform &transform) {
        UpdateMatrices(transform);
    }

    void Camera::UpdateMatrices(const Transform &transform) {
        transform_ = transform;

        Matrix4x4 cameraMatrix = Math::MakeAffineMatrix(
            transform.scale,
            transform.rotate,
            transform.translate);

        viewMatrix_ = Math::Inverse(cameraMatrix);

        projectionMatrix_ = Math::MakePerspectiveFovMatrix(
            fovY_,
            width_ / height_,
            nearClip_,
            farClip_);

        viewProjectionMatrix_ =
            Math::Multiply(viewMatrix_, projectionMatrix_);
    }

}