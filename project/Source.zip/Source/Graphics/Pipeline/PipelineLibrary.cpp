#include "PipelineLibrary.h"

#include "RootSignature.h"
#include "GraphicsPipeline.h"
#include "PipelineDescBuilder.h"
#include "Graphics/Resource/Shader.h"

#include "Utils/Debug/Logger.h"

#include <cassert>

namespace Tuna {

    void PipelineLibrary::Initialize(
        ID3D12Device *device
    ) {
        device_ = device;

        //====================
        // 初期Config
        //====================

        configs_[PipelineMode::Object3DOpaque] = {
            .rasterizer = RasterizerMode::Default,
            .depth = DepthMode::Default,
            .blend = BlendMode::Default,
            .inputLayout = InputLayoutMode::Default
        };

        configs_[PipelineMode::Object3DAlpha] = {
            .rasterizer = RasterizerMode::NoCull,
            .depth = DepthMode::Alpha,
            .blend = BlendMode::Alpha,
            .inputLayout = InputLayoutMode::Default
        };

        configs_[PipelineMode::Object3DWireframe] = {
            .rasterizer = RasterizerMode::Wireframe,
            .depth = DepthMode::Default,
            .blend = BlendMode::Default,
            .inputLayout = InputLayoutMode::Default
        };

        configs_[PipelineMode::Object3DThroughWall] = {
            .rasterizer = RasterizerMode::Default,
            .depth = DepthMode::ThroughWall,
            .blend = BlendMode::Alpha,
            .inputLayout = InputLayoutMode::Default
        };

        configs_[PipelineMode::Object2DOpaque] = {
            .rasterizer = RasterizerMode::NoCull,
            .depth = DepthMode::Disable,
            .blend = BlendMode::Default,
            .inputLayout = InputLayoutMode::Default
        };

        configs_[PipelineMode::Model3DOpaque] = {
            .rasterizer = RasterizerMode::Default,
            .depth = DepthMode::Default,
            .blend = BlendMode::Default,
            .inputLayout = InputLayoutMode::Model3d
        };

        configs_[PipelineMode::Particle] = {
            .rasterizer = RasterizerMode::NoCull,
            .depth = DepthMode::Alpha,
            .blend = BlendMode::Add,
            .inputLayout = InputLayoutMode::Model3d
        };

        //====================
        // Pipeline生成
        //====================

        CreateObject3DOpaque(device);
        CreateObject3DAlpha(device);
        CreateObject3DWireframe(device);
        CreateObject3DThroughWall(device);

        CreateObject2DOpaque(device);

        CreateModel3DOpaque(device);

        CreateParticle(device);
    }


    //==================================================
    // 3D Object
    //==================================================

    void PipelineLibrary::CreateObject3DOpaque(
        ID3D12Device *device
    ) {
        //====================
        // Config
        //====================

        PipelineConfig &config =
            configs_[PipelineMode::Object3DOpaque];

        //====================
        // HLSL読み込み
        //====================
        Shader vs, ps;

        vs.Compile(
            L"Resources/Shader/Object3D.VS.hlsl",
            L"vs_6_0"
        );

        ps.Compile(
            L"Resources/Shader/Object3D.PS.hlsl",
            L"ps_6_0"
        );


        //====================
        // RootSignature生成
        //====================

        auto rootSignature =
            std::make_unique<RootSignature>();

        rootSignature->Create(device, RootSignature::Mode::Lit3D);

        //====================
        // Pipeline生成
        //====================

        auto pipeline =
            std::make_unique<GraphicsPipeline>();

        auto inputLayout =
            PipelineDescBuilder::CreateInputLayout(
                config.inputLayout
            );

        pipeline->Initialize(
            device,
            rootSignature->GetRootSignature(),
            vs,
            ps,
            inputLayout,
            PipelineDescBuilder::CreateRasterizer(
                config.rasterizer
            ),
            PipelineDescBuilder::CreateDepthStencil(
                config.depth
            ),
            PipelineDescBuilder::CreateBlendState(
                config.blend
            )
        );


        //====================
        // Pipeline登録
        //====================

        pipelines_[PipelineMode::Object3DOpaque] =
        {
            std::move(rootSignature),
            std::move(pipeline)
        };
    }


    void PipelineLibrary::CreateObject3DAlpha(
        ID3D12Device *device
    ) {
        //====================
        // Config
        //====================

        PipelineConfig &config =
            configs_[PipelineMode::Object3DAlpha];

        //====================
        // HLSL読み込み
        //====================

        Shader vs, ps;

        vs.Compile(
            L"Resources/Shader/Object3D.VS.hlsl",
            L"vs_6_0"
        );

        ps.Compile(
            L"Resources/Shader/Object3D.PS.hlsl",
            L"ps_6_0"
        );


        //====================
        // RootSignature生成
        //====================

        auto rootSignature =
            std::make_unique<RootSignature>();

        rootSignature->Create(device, RootSignature::Mode::Lit3D);

        //====================
        // Pipeline生成
        //====================

        auto pipeline =
            std::make_unique<GraphicsPipeline>();

        auto inputLayout =
            PipelineDescBuilder::CreateInputLayout(
                config.inputLayout
            );

        pipeline->Initialize(
            device,
            rootSignature->GetRootSignature(),
            vs,
            ps,
            inputLayout,
            PipelineDescBuilder::CreateRasterizer(
                config.rasterizer
            ),
            PipelineDescBuilder::CreateDepthStencil(
                config.depth
            ),
            PipelineDescBuilder::CreateBlendState(
                config.blend
            )
        );


        //====================
        // Pipeline登録
        //====================

        pipelines_[PipelineMode::Object3DAlpha] =
        {
            std::move(rootSignature),
            std::move(pipeline)
        };
    }


    void PipelineLibrary::CreateObject3DWireframe(
        ID3D12Device *device
    ) {
        //====================
        // Config
        //====================

        PipelineConfig &config =
            configs_[PipelineMode::Object3DWireframe];

        //====================
        // HLSL読み込み
        //====================

        Shader vs, ps;

        vs.Compile(
            L"Resources/Shader/Object3D.VS.hlsl",
            L"vs_6_0"
        );

        ps.Compile(
            L"Resources/Shader/Object3D.PS.hlsl",
            L"ps_6_0"
        );


        //====================
        // RootSignature生成
        //====================

        auto rootSignature =
            std::make_unique<RootSignature>();

        rootSignature->Create(device, RootSignature::Mode::Lit3D);


        //====================
        // Pipeline生成
        //====================

        auto pipeline =
            std::make_unique<GraphicsPipeline>();

        auto inputLayout =
            PipelineDescBuilder::CreateInputLayout(
                config.inputLayout
            );

        pipeline->Initialize(
            device,
            rootSignature->GetRootSignature(),
            vs,
            ps,
            inputLayout,
            PipelineDescBuilder::CreateRasterizer(
                config.rasterizer
            ),
            PipelineDescBuilder::CreateDepthStencil(
                config.depth
            ),
            PipelineDescBuilder::CreateBlendState(
                config.blend
            )
        );


        //====================
        // Pipeline登録
        //====================

        pipelines_[PipelineMode::Object3DWireframe] =
        {
            std::move(rootSignature),
            std::move(pipeline)
        };
    }


    void PipelineLibrary::CreateObject3DThroughWall(
        ID3D12Device *device
    ) {
        //====================
        // Config
        //====================


        PipelineConfig &config =
            configs_[PipelineMode::Object3DThroughWall];


        //====================
        // HLSL読み込み
        //====================

        Shader vs, ps;

        vs.Compile(
            L"Resources/Shader/Object3D.VS.hlsl",
            L"vs_6_0"
        );

        ps.Compile(
            L"Resources/Shader/ThroughWall3D.PS.hlsl",
            L"ps_6_0"
        );


        //====================
        // RootSignature生成
        //====================

        auto rootSignature =
            std::make_unique<RootSignature>();

        rootSignature->Create(device, RootSignature::Mode::Lit3D);


        //====================
        // Pipeline生成
        //====================

        auto pipeline =
            std::make_unique<GraphicsPipeline>();

        auto inputLayout =
            PipelineDescBuilder::CreateInputLayout(
                config.inputLayout
            );

        pipeline->Initialize(
            device,
            rootSignature->GetRootSignature(),
            vs,
            ps,
            inputLayout,
            PipelineDescBuilder::CreateRasterizer(
                config.rasterizer
            ),
            PipelineDescBuilder::CreateDepthStencil(
                config.depth
            ),
            PipelineDescBuilder::CreateBlendState(
                config.blend
            )
        );


        //====================
        // Pipeline登録
        //====================

        pipelines_[PipelineMode::Object3DThroughWall] =
        {
            std::move(rootSignature),
            std::move(pipeline)
        };
    }


    //==================================================
    // 2D Object
    //==================================================

    void PipelineLibrary::CreateObject2DOpaque(
        ID3D12Device *device
    ) {
        //====================
        // Config
        //====================


        PipelineConfig &config =
            configs_[PipelineMode::Object2DOpaque];


        //====================
        // HLSL読み込み
        //====================

        Shader vs, ps;

        vs.Compile(
            L"Resources/Shader/Object2D.VS.hlsl",
            L"vs_6_0"
        );

        ps.Compile(
            L"Resources/Shader/Object2D.PS.hlsl",
            L"ps_6_0"
        );


        //====================
        // RootSignature生成
        //====================

        auto rootSignature =
            std::make_unique<RootSignature>();

        rootSignature->Create(device, RootSignature::Mode::Unlit2D);


        //====================
        // Pipeline生成
        //====================

        auto pipeline =
            std::make_unique<GraphicsPipeline>();

        auto inputLayout =
            PipelineDescBuilder::CreateInputLayout(
                config.inputLayout
            );

        pipeline->Initialize(
            device,
            rootSignature->GetRootSignature(),
            vs,
            ps,
            inputLayout,
            PipelineDescBuilder::CreateRasterizer(
                config.rasterizer
            ),
            PipelineDescBuilder::CreateDepthStencil(
                config.depth
            ),
            PipelineDescBuilder::CreateBlendState(
                config.blend
            )
        );


        //====================
        // Pipeline登録
        //====================

        pipelines_[PipelineMode::Object2DOpaque] =
        {
            std::move(rootSignature),
            std::move(pipeline)
        };
    }


    //==================================================
    // Model
    //==================================================

    void PipelineLibrary::CreateModel3DOpaque(
        ID3D12Device *device
    ) {
        //====================
        // Config
        //====================

        PipelineConfig &config =
            configs_[PipelineMode::Model3DOpaque];


        //====================
        // HLSL読み込み
        //====================

        Shader vs, ps;

        vs.Compile(
            L"Resources/Shader/Model3D.VS.hlsl",
            L"vs_6_0"
        );

        ps.Compile(
            L"Resources/Shader/Model3D.PS.hlsl",
            L"ps_6_0"
        );


        //====================
        // RootSignature生成
        //====================

        auto rootSignature =
            std::make_unique<RootSignature>();

        rootSignature->Create(device, RootSignature::Mode::Lit3D);


        //====================
        // Pipeline生成
        //====================

        auto pipeline =
            std::make_unique<GraphicsPipeline>();

        auto inputLayout =
            PipelineDescBuilder::CreateInputLayout(
                config.inputLayout
            );

        pipeline->Initialize(
            device,
            rootSignature->GetRootSignature(),
            vs,
            ps,
            inputLayout,
            PipelineDescBuilder::CreateRasterizer(
                config.rasterizer
            ),
            PipelineDescBuilder::CreateDepthStencil(
                config.depth
            ),
            PipelineDescBuilder::CreateBlendState(
                config.blend
            )
        );


        //====================
        // Pipeline登録
        //====================

        pipelines_[PipelineMode::Model3DOpaque] =
        {
            std::move(rootSignature),
            std::move(pipeline)
        };
    }

    void PipelineLibrary::CreateParticle(
        ID3D12Device *device
    ) {
        //====================
        // Config
        //====================

        PipelineConfig &config =
            configs_[PipelineMode::Particle];

        //====================
        // HLSL読み込み
        //====================

        Shader vs, ps;

        vs.Compile(
            L"Resources/Shader/Particle.VS.hlsl",
            L"vs_6_0"
        );

        ps.Compile(
            L"Resources/Shader/Particle.PS.hlsl",
            L"ps_6_0"
        );

        //====================
        // RootSignature生成
        //====================

        auto rootSignature =
            std::make_unique<RootSignature>();

        rootSignature->Create(device, RootSignature::Mode::Particles);

        //====================
        // Pipeline生成
        //====================

        auto pipeline =
            std::make_unique<GraphicsPipeline>();

        auto inputLayout =
            PipelineDescBuilder::CreateInputLayout(
                config.inputLayout
            );

        pipeline->Initialize(
            device,
            rootSignature->GetRootSignature(),
            vs,
            ps,
            inputLayout,
            PipelineDescBuilder::CreateRasterizer(
                config.rasterizer
            ),
            PipelineDescBuilder::CreateDepthStencil(
                config.depth
            ),
            PipelineDescBuilder::CreateBlendState(
                config.blend
            )
        );

        //====================
        // Pipeline登録
        //====================

        pipelines_[PipelineMode::Particle] = {
            std::move(rootSignature),
            std::move(pipeline)
        };
    }

    //==================================================
    // Get Pipeline
    //==================================================

    const PipelineState *PipelineLibrary::GetPipeline(
        PipelineMode mode
    ) const {
        auto it = pipelines_.find(mode);

        if (it != pipelines_.end()) {
            return &it->second;
        }

        assert(
            false &&
            "指定されたパイプラインは存在しません"
        );

        return nullptr;
    }

    PipelineConfig &PipelineLibrary::GetConfig(
        PipelineMode mode
    ) {
        return configs_.at(mode);
    }

    void PipelineLibrary::RebuildPipeline(
        PipelineMode mode
    ) {
        switch (mode) {

        case PipelineMode::Object3DOpaque:
            CreateObject3DOpaque(device_);
            break;

        case PipelineMode::Object3DAlpha:
            CreateObject3DAlpha(device_);
            break;

        case PipelineMode::Object3DWireframe:
            CreateObject3DWireframe(device_);
            break;

        case PipelineMode::Object3DThroughWall:
            CreateObject3DThroughWall(device_);
            break;

        case PipelineMode::Object2DOpaque:
            CreateObject2DOpaque(device_);
            break;

        case PipelineMode::Model3DOpaque:
            CreateModel3DOpaque(device_);
            break;

        case PipelineMode::Particle:
            CreateParticle(device_);
            break;
        }
    }
}