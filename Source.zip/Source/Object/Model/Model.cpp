#include "Model.h"

#include <cassert>
#include <filesystem>

#include "Math/FunctionMatrix.h"

namespace Tuna {

    void Model::Create(
        ID3D12Device *device,
        ID3D12GraphicsCommandList *commandList,
        uint32_t color,
        bool enableLighting) {

        assert(device);
        assert(commandList);
        assert(modelData_);

        // 外部テクスチャを指定していない場合、
        // モデルと同名のテクスチャを読み込む
        if (!useExternalTexture_) {
            assert(textureManager_ != nullptr);

            std::string texturePath = FindTexturePath();

            if (!texturePath.empty()) {
                textureData_ =
                    textureManager_->LoadTexture(
                        commandList,
                        texturePath);
            }
        }

        // 行列用定数バッファを生成
        renderer_.CreateTransformationMatrixBuffer(
            device,
            transformationMatrixBuffer_,
            transformationMatrixData_);

        // マテリアルを初期化
        material_.Initialize(
            device,
            color,
            enableLighting);
    }

    void Model::Update(
        CameraManager *camera) {

        Matrix4x4 worldMatrix =
            Math::MakeAffineMatrix(
                transform_.scale,
                transform_.rotate,
                transform_.translate);

        Matrix4x4 wvp =
            Math::Multiply(
                worldMatrix,
                camera->GetViewProjectionMatrix());

        transformationMatrixData_->World =
            worldMatrix;

        transformationMatrixData_->WVP =
            wvp;

        // UV Transform
        Matrix4x4 uvTransformMatrix{};

        uvTransformMatrix =
            Math::MakeScaleMatrix(
                uvTransform_.scale);

        uvTransformMatrix =
            Math::Multiply(
                uvTransformMatrix,
                Math::MakeRotateZMatrix(
                    uvTransform_.rotate.z));

        uvTransformMatrix =
            Math::Multiply(
                uvTransformMatrix,
                Math::MakeTranslateMatrix(
                    uvTransform_.translate));

        material_.GetMaterialData()->uvTransform =
            uvTransformMatrix;
    }

    void Model::Draw(
        ID3D12GraphicsCommandList *commandList) {

        commandList->SetGraphicsRootConstantBufferView(
            0,
            material_.GetGPUVirtualAddress());

        commandList->SetGraphicsRootConstantBufferView(
            1,
            transformationMatrixBuffer_.GetGPUVirtualAddress());

        if (textureData_.gpuHandle.ptr != 0) {
            commandList->SetGraphicsRootDescriptorTable(
                2,
                textureData_.gpuHandle);
        }

        // 共有メッシュを描画
        modelData_->mesh.Bind(commandList);
    }

    std::string Model::FindTexturePath() const {

        const std::string directory =
            "Resources/Models/" + fileName_ + "/";

        const std::string extensions[] = {
            ".png",
            ".jpg",
            ".jpeg"
        };

        for (const auto &extension : extensions) {

            std::filesystem::path path =
                directory + fileName_ + extension;

            if (std::filesystem::exists(path)) {
                return path.string();
            }
        }

        return "";
    }
}